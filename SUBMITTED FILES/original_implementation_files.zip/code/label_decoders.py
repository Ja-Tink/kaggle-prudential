# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 11:35:10 2016

@author: bohdan
"""

def labels_decoder1(lb):
    lb = [1 if x == 1 else 0 for x in lb]    
    return lb


def labels_decoder2(lb):
    lb = [1 if x == 2 else 0 for x in lb]    
    return lb


def labels_decoder3(lb):
    lb = [1 if x == 3 else 0 for x in lb]    
    return lb


def labels_decoder4(lb):
    lb = [1 if x == 4 else 0 for x in lb]    
    return lb


def labels_decoder5(lb):
    lb = [1 if x == 5 else 0 for x in lb]    
    return lb


def labels_decoder6(lb):
    lb = [1 if x == 6 else 0 for x in lb]    
    return lb


def labels_decoder7(lb):
    lb = [1 if x == 7 else 0 for x in lb]    
    return lb 


def labels_decoder8(lb):
    lb = [1 if x == 8 else 0 for x in lb]    
    return lb


def labels_decoder9(lb):
    lb = [1 if x < 3 else 0 for x in lb]    
    return lb


def labels_decoder10(lb):
    lb = [1 if x < 4 else 0 for x in lb]    
    return lb


def labels_decoder11(lb):
    lb = [1 if x < 5 else 0 for x in lb]    
    return lb


def labels_decoder12(lb):
    lb = [1 if x < 6 else 0 for x in lb]    
    return lb


def labels_decoder13(lb):
    lb = [1 if x < 7 else 0 for x in lb]    
    return lb